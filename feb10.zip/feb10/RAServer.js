// global variables
const fs = require('fs');

var express = require('express')
var app = express()
var path = require('path');

app.use(express.static('public'))

var currSenScore=0;
var currSenMag=0;
var currKey1="";
var currKey2="";
var wordlist=[];
var taglist=[];



app.get('/query/:bookname', function (req, res) {
    //console.log(req.params.bookname);
    var currbook;
    fs.readFile(req.params.bookname, (err,data) =>{
        if(err) throw err;
        currbook = JSON.parse(data);
        res.json(currbook);
        //console.log(currbook);
    })
})


async function getSentiment(text, callback, res) {
  
  const language = require('@google-cloud/language');
  const client = new language.LanguageServiceClient();
  
  const document = {
    content: text,
    type: 'PLAIN_TEXT',
  };

  // Detects the sentiment of the text
  const [sent_result] = await client.analyzeSentiment({document: document});
  const sentiment = sent_result.documentSentiment;

  //console.log(`Text: ${text}`);
  currSenScore = sentiment.score;
  currSenMag = sentiment.magnitude;
  //console.log(`Sentiment score: ${sentiment.score}`);
  //console.log(`Sentiment magnitude: ${sentiment.magnitude}`);
  callback(res);
}

app.get('/Senfor/:SenAl', function (req, res) {
    //console.log(req.params.SenAl);
    getSentiment(req.params.SenAl, ()=>{
		res.json([currSenScore, currSenMag]);
    },res).catch(console.error);
})


async function getKeyWords(text, callback, res){
	const language = require('@google-cloud/language');
	const client = new language.LanguageServiceClient();
  
	const document = {
    	content: text,
    	type: 'PLAIN_TEXT',
  	};
	const [sent_result] = await client.analyzeEntities({document});
	const keywords = sent_result.entities;
	//console.log(keywords);
	currKey1=keywords[0].name;
	currKey2=keywords[1].name;
	callback(res);
}

app.get('/Keyfor/:KeyAl', function (req,res){
	//console.log(req.params.KeyAl);
	getKeyWords(req.params.KeyAl, ()=>{
		res.json([currKey1, currKey2]);
	},res).catch(console.error);
})





async function getSyntax(text, callback, res) {
	wordlist=[];
	taglist=[];
  const language = require('@google-cloud/language');
  const client = new language.LanguageServiceClient();
  const document = {
    content: text,
    type: 'PLAIN_TEXT',
  };
  const [result] = await client.analyzeSyntax({document});
  const syntax = result.tokens; 
  console.log(syntax.length);


  for(var i=0; i<syntax.length; i++){
  	wordlist.push(syntax[i].text.content);
  	taglist.push(syntax[i].partOfSpeech.tag);
  }

  callback(res);
} 

app.get('/Synfor/:SynAl', function (req,res){
	//console.log(req.params.SynAl);
	getSyntax(req.params.SynAl, ()=>{
		res.json([wordlist,taglist]);
	},res).catch(console.error);
})




app.listen(3000)

// create a Web server instance

// Create a node-static server instance to serve the './public' folder

// called on http request arrival event






